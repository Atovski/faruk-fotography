'use client';

import styled from 'styled-components';
import { theme } from '@/styles/theme';
import { fadeInUp } from '@/styles/animations';
import { useLanguage } from '@/hooks/useLanguage';
import SectionTitle from '@/components/ui/SectionTitle';
import { Button } from '@/components/ui/Button';
import { HiCamera, HiFilm, HiPhotograph, HiGift, HiCheck, HiUsers, HiShoppingBag } from 'react-icons/hi';
import { FaWhatsapp } from 'react-icons/fa';
import { getWhatsAppUrl } from '@/lib/utils';

const PageWrapper = styled.div`
  padding-top: 100px;
  min-height: 100vh;
`;

const Container = styled.div`
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 ${theme.spacing.lg} ${theme.spacing['4xl']};
`;

const ServiceBlock = styled.div<{ $reverse?: boolean }>`
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: ${theme.spacing['3xl']};
  align-items: center;
  padding: ${theme.spacing['3xl']} 0;
  border-bottom: 1px solid ${theme.colors.glassBorder};
  animation: ${fadeInUp} 0.6s ease forwards;

  &:last-child {
    border-bottom: none;
  }

  ${({ $reverse }) => $reverse && `
    direction: rtl;
    & > * {
      direction: ltr;
    }
  `}

  @media (max-width: ${theme.breakpoints.laptop}) {
    grid-template-columns: 1fr;
    direction: ltr;
    & > * { direction: ltr; }
  }
`;

const ServiceInfo = styled.div``;

const ServiceIcon = styled.div`
  width: 64px;
  height: 64px;
  border-radius: ${theme.borderRadius.lg};
  background: ${theme.colors.secondary}15;
  color: ${theme.colors.secondary};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  margin-bottom: ${theme.spacing.lg};
`;

const ServiceName = styled.h2`
  font-family: ${theme.fonts.heading};
  font-size: ${theme.fontSizes['3xl']};
  color: ${theme.colors.text};
  margin-bottom: ${theme.spacing.md};
`;

const ServiceDesc = styled.p`
  font-size: ${theme.fontSizes.md};
  color: ${theme.colors.textSecondary};
  line-height: 1.8;
  margin-bottom: ${theme.spacing.xl};
`;

const FeatureList = styled.ul`
  list-style: none;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: ${theme.spacing.sm};
  margin-bottom: ${theme.spacing.xl};
`;

const Feature = styled.li`
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: ${theme.fontSizes.md};
  color: ${theme.colors.textSecondary};

  svg {
    color: ${theme.colors.secondary};
    flex-shrink: 0;
  }
`;

const ServiceVisual = styled.div`
  background: ${theme.colors.gradientCard};
  border-radius: ${theme.borderRadius.xl};
  border: 1px solid ${theme.colors.glassBorder};
  height: 350px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  position: relative;

  &::before {
    content: '';
    position: absolute;
    inset: 0;
    background: radial-gradient(ellipse at center, ${theme.colors.secondary}10 0%, transparent 70%);
  }
`;

const BigIcon = styled.div`
  font-size: 80px;
  color: ${theme.colors.secondary}30;
  z-index: 1;
`;

const PriceTag = styled.div`
  display: inline-flex;
  align-items: baseline;
  gap: 4px;
  padding: 8px 20px;
  border-radius: ${theme.borderRadius.full};
  background: ${theme.colors.secondary}15;
  border: 1px solid ${theme.colors.secondary}30;
  margin-bottom: ${theme.spacing.lg};

  span:first-child {
    font-size: ${theme.fontSizes.sm};
    color: ${theme.colors.textSecondary};
  }

  span:last-child {
    font-size: ${theme.fontSizes['2xl']};
    font-weight: 700;
    color: ${theme.colors.secondary};
    font-family: ${theme.fonts.heading};
  }
`;

const services = [
  {
    key: 'passport' as const,
    icon: HiCamera,
    price: '450',
    whatsappMsg: 'Merhaba, vesikalık fotoğraf çektirmek istiyorum.',
  },
  {
    key: 'studio' as const,
    icon: HiUsers,
    price: '1500',
    whatsappMsg: 'Merhaba, stüdyo çekimi (portre/özel gün) hakkında detaylı bilgi almak istiyorum.',
  },
  {
    key: 'film' as const,
    icon: HiFilm,
    price: '350',
    whatsappMsg: 'Merhaba, film banyo yaptırmak istiyorum.',
  },
  {
    key: 'print' as const,
    icon: HiPhotograph,
    price: '50',
    whatsappMsg: 'Merhaba, fotoğraf baskı yaptırmak istiyorum.',
  },
  {
    key: 'equipment' as const,
    icon: HiShoppingBag,
    price: '100', // Basic film/equipment starting price
    whatsappMsg: 'Merhaba, fotoğraf makinesi ve analog film ekipmanları/stokları hakkında bilgi almak istiyorum.',
  },
  {
    key: 'sublimation' as const,
    icon: HiGift,
    price: '150',
    whatsappMsg: 'Merhaba, kişiselleştirilebilir ürün (kupa/magnet) sipariş etmek istiyorum.',
  },
];

export default function ServicesPage() {
  const { t } = useLanguage();

  return (
    <PageWrapper>
      <Container>
        <SectionTitle
          badge={t.services.subtitle}
          title={t.services.title}
          as="h1"
        />

        {services.map((service, index) => {
          const Icon = service.icon;
          const data = t.services[service.key];
          return (
            <ServiceBlock key={service.key} $reverse={index % 2 === 1}>
              <ServiceInfo>
                <ServiceIcon><Icon /></ServiceIcon>
                <ServiceName>{data.title}</ServiceName>
                <PriceTag>
                  <span>{t.common.startingFrom}</span>
                  <span>₺{service.price}</span>
                </PriceTag>
                <ServiceDesc>{data.description}</ServiceDesc>
                <FeatureList>
                  {data.features.map((feature, i) => (
                    <Feature key={i}>
                      <HiCheck size={18} />
                      {feature}
                    </Feature>
                  ))}
                </FeatureList>
                <Button
                  as="a"
                  href={getWhatsAppUrl(service.whatsappMsg)}
                  target="_blank"
                  rel="noopener noreferrer"
                  $variant="whatsapp"
                  $size="md"
                >
                  <FaWhatsapp /> {t.hero.cta}
                </Button>
              </ServiceInfo>

              <ServiceVisual>
                <BigIcon><Icon /></BigIcon>
              </ServiceVisual>
            </ServiceBlock>
          );
        })}
      </Container>
    </PageWrapper>
  );
}
